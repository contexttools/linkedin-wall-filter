# linkedin-wall-filter
Filter wall by tags, words, phrase


## testing

[Getting started with web-ext | Firefox Extension Workshop](https://extensionworkshop.com/documentation/develop/getting-started-with-web-ext/)

tool install
```bash
npm install --global web-ext
```
npm install -g web-ext


> ### Testing out an extension
>
> Test an extension in Firefox by `cd`'ing into your extensions’s root directory and entering:
```bash
web-ext run
```


## Packaging extension

Once you've tested your extension and verified that it's working, you can turn it into a package for submitting to addons.mozilla.org using the following command:

```bash
web-ext build
```
